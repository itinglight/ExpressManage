<template>
  <div class="about">
    <h1>我寄出的</h1>
  </div>
</template>
