<template>
  <div class="about">
    <h1>我收到的</h1>
  </div>
</template>
