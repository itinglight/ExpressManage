<template>
  <div class="home">
    <h1>菜鸟物流管理系统</h1>
   <div class="buttons"> <router-link to="/register"><el-button type="primary">注册</el-button></router-link></div>
    <div class="buttons" ><router-link to="/login"><el-button type="primary">登录</el-button></router-link> </div>

  
  </div>
</template>


<style scoped>
.home{
  font-size: 39px;
  color: rgb(0, 136, 255);
}
h1:hover{
  color:greenyellow;
  }
  .buttons{

  }
</style>