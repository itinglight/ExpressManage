<template>
  <div class="register">
    <h1>注册账号</h1>

    <div class="divs">
    <el-input v-model="input1" placeholder="请输入手机号码"></el-input>
    <el-input v-model="input2" placeholder="请设置密码"></el-input>
    <el-input v-model="input3" placeholder="请确认密码"></el-input>
    </div>
<div class="register_button"><el-button  type="primary" @click="commit()">注册账号</el-button></div>
<router-link class="back_button" to="/"><el-button type="primary">回到首页</el-button></router-link>
  </div>
</template>
<script>

export default {
  data() {
    return {
      input1: '',
      input2: '',
      input3: '',
      input4: ''
    }
  }
}

</script>
  

<style>
.divs{

  /* width: 30%; */

}
.register_button{

position: absolute;
width: 83px;
height: 83px;
left: 440px;
top: 389px;
  
}
.back_button{
  position: absolute;
  width: 83px;
  height: 83px;
  left: 540px;
  top: 389px;

}

</style>