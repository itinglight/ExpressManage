<template>
  <div id="app">
      <el-container style="height: 800px; border: 1px solid #eee">
  <!-- 构建左侧菜单 -->
 
  
  <el-container>
    <el-header style="text-align: right; font-size: 12px">
      <el-dropdown>
        <i class="el-icon-setting" style="margin-right: 15px"></i>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>查看</el-dropdown-item>
          <el-dropdown-item>新增</el-dropdown-item>
          <el-dropdown-item>删除</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <span>菜鸟物流管理系统</span>
    </el-header>
    
    <el-main>
      <!-- 页面刷新的地方 -->
     <router-view></router-view>
    </el-main>
  </el-container>
</el-container>
  
  </div>
</template>

<style >
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {
    color: #333;
  }
</style>

<script>

</script>