<template>
  <div class="login">

    <h1>登录账号</h1>
    <div>
          <div class="username" > <el-input  placeholder="请输入账号" suffix-icon="el-icon-date" v-model="username"></el-input></div>
          <div class="password"> <el-input placeholder="请输入密码" show-password v-model="password"></el-input></div>
    </div>
      
     <div class="login_button"><el-button  type="primary" @click="commit()">登录</el-button></div>
    
      <router-link class="back_button" to="/"><el-button type="primary">回到首页</el-button></router-link>
        <a href="http://localhost:8082">用户登录成功进入的页面</a>
  </div>
</template>
<script>
export default {
  data(){
    return {
    username:'',
    password:''
    }
 
    },
    methods: {
    commit(){

      if(this.username=='itinglight'){
        alert("登录成功");
        
      }else{
        alert("请确检查密码或账号是否正确")
      }
   

    }
  }
}

</script>
<style lang="css" scoped>

.username{
  width:30%;
  position: absolute;
  width: 332px;
  height: 60px;
  left: 404px;
  top: 269px;

  }
.password{

position: absolute;
width: 332px;
height: 60px;
left: 404px;
top: 313px;

}
.login_button{

position: absolute;
width: 83px;
height: 83px;
left: 440px;
top: 389px;
  
  }
h1{
  position: absolute;

  left: 500px;
  top: 150px;
  }
.back_button{
  position: absolute;
  width: 83px;
  height: 83px;
  left: 540px;
  top: 389px;

}


</style>